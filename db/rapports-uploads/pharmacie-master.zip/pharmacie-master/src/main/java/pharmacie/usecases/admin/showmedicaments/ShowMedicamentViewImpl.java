package pharmacie.usecases.admin.showmedicaments;

public class ShowMedicamentViewImpl implements ShowMedicamentView {

  public String generateView(ShowMedicamentViewModel viewModel)
  {
    return "";
  }
}
