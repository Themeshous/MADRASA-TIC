package pharmacie.usecases.client.savesale;

public interface AddSaleOutputBoundary {
  void present(AddSaleResponseModel responseModel);
}
