package pharmacie.usecases.admin.deletemedicament;

public class DeleteMedicamentResponseModel {

  public boolean medicamentDeleted;
}
