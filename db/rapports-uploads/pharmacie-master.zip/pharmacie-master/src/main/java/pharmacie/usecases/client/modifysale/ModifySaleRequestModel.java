package pharmacie.usecases.client.modifysale;

import pharmacie.entities.Sale;

public class ModifySaleRequestModel {
  public Sale sale;
}
