package pharmacie.usecases.client.deletesale;

public interface DeleteSaleOutputBoundary {
  void present(DeleteSaleResponseModel responseModel);
}
