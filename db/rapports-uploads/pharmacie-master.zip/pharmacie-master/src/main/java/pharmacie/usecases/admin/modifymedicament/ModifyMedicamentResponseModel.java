package pharmacie.usecases.admin.modifymedicament;

public class ModifyMedicamentResponseModel {
  public boolean MedicamentModified;
}
