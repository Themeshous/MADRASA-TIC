package pharmacie.usecases.authentication.login;

public record LoginInformation(String username, String password) {
}
