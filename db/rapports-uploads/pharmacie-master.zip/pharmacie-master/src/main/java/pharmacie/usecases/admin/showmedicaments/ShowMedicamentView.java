package pharmacie.usecases.admin.showmedicaments;

public interface ShowMedicamentView
{
  String generateView(ShowMedicamentViewModel viewModel);
}
