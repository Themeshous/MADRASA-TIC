package pharmacie.usecases.admin.addmedicament;

public interface AddMedicamentOutputBoundary {
  void present(AddMedicamentResponseModel responseModel);
}
