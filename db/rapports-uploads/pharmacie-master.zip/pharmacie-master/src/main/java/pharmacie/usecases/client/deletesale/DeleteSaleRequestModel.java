package pharmacie.usecases.client.deletesale;

import pharmacie.entities.Sale;

public class DeleteSaleRequestModel {

  public Sale sale;
}
