package pharmacie.usecases;

public interface Controller {
}
