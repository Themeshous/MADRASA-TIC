package pharmacie.usecases.admin.modifymedicament;

import pharmacie.entities.Medicament;

public class ModifyMedicamentRequestModel {
  public Medicament medicament;
}
