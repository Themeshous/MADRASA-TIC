package pharmacie.usecases.admin.addmedicament;

public class AddMedicamentResponseModel {

  public boolean medicamentSaved;
}
