package pharmacie.usecases.client.savesale;

import pharmacie.entities.Sale;

public class AddSaleResponseModel {

  public boolean saleSaved;
}
