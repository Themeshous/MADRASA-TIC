package pharmacie.usecases.admin.modifymedicament;

public interface ModifyMedicamentOutputBoundary {
  void present(ModifyMedicamentResponseModel responseModel);
}
