package pharmacie.usecases.client.showsales;

public interface ShowSalesView
{
  String generateView(ShowSalesViewModel viewModel);
}
