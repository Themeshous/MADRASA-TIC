package pharmacie.usecases.admin.deletemedicament;

import pharmacie.entities.Medicament;

public class DeleteMedicamentRequestModel {

  public Medicament medicament;
}
