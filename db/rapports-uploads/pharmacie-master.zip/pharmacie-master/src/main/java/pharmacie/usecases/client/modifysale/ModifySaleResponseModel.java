package pharmacie.usecases.client.modifysale;

public class ModifySaleResponseModel {
  public boolean saleModified;
}
