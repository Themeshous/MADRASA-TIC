package pharmacie.usecases.client.showsales;

import java.io.IOException;
import java.util.List;

public class ShowSalesViewImpl implements ShowSalesView
{

  public String generateView(ShowSalesViewModel viewModel)
  {
    return "";
  }
}
