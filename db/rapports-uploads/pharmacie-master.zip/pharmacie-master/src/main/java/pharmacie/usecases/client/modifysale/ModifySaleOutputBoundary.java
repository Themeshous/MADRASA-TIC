package pharmacie.usecases.client.modifysale;

public interface ModifySaleOutputBoundary {
  void present(ModifySaleResponseModel responseModel);
}
