package pharmacie.usecases.client.deletesale;

public class DeleteSaleResponseModel {

  public boolean saleDeleted;
}
