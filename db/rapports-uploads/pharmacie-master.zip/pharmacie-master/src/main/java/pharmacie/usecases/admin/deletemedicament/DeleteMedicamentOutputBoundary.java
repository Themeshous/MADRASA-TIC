package pharmacie.usecases.admin.deletemedicament;

public interface DeleteMedicamentOutputBoundary {
  void present(DeleteMedicamentResponseModel responseModel);
}
