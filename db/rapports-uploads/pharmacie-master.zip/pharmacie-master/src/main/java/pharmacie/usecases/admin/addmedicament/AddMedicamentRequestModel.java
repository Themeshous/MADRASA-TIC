package pharmacie.usecases.admin.addmedicament;

import pharmacie.entities.Medicament;

public class AddMedicamentRequestModel {
  public Medicament medicament;
}
