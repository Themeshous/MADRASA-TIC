package pharmacie.usecases.client.savesale;

public class SaveSaleController {
}
