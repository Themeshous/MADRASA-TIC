package pharmacie.usecases.admin.showmedicaments;

import java.time.LocalDate;

public class MedicamentSummary {
  public String medicamentName;
  public int quantity;
  public LocalDate experationDate;
  public int price;
}
